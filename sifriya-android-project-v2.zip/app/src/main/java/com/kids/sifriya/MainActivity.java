package com.kids.sifriya;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                fileCallback = cb;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    return false;
                }
                startActivityForResult(intent, 42);
                return true;
            }
        });

        web.loadUrl("file:///android_asset/sifriya.html");
        setContentView(web);
    }

    /* ===== גשר אחסון: הספרים נשמרים בזיכרון הפנימי של האפליקציה ===== */
    public class Bridge {
        private File dir() {
            File d = new File(getFilesDir(), "books");
            if (!d.exists()) d.mkdirs();
            return d;
        }
        private File index() { return new File(dir(), "index.json"); }

        @JavascriptInterface
        public String listBooks() {
            try {
                File f = index();
                if (!f.exists()) return "[]";
                byte[] buf = new byte[(int) f.length()];
                FileInputStream in = new FileInputStream(f);
                in.read(buf);
                in.close();
                return new String(buf, StandardCharsets.UTF_8);
            } catch (Exception e) { return "[]"; }
        }

        private void saveIndex(JSONArray arr) throws Exception {
            FileOutputStream out = new FileOutputStream(index());
            out.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            out.close();
        }

        @JavascriptInterface
        public boolean beginSave(String id, String name) {
            try {
                pendingOut = new FileOutputStream(new File(dir(), id + ".pdf"));
                pendingId = id;
                pendingName = name;
                return true;
            } catch (Exception e) { return false; }
        }
        private FileOutputStream pendingOut;
        private String pendingId, pendingName;

        @JavascriptInterface
        public boolean saveChunk(String b64) {
            try {
                pendingOut.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean endSave() {
            try {
                pendingOut.close();
                long size = new File(dir(), pendingId + ".pdf").length();
                JSONArray arr = new JSONArray(listBooks());
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    if (o.getString("id").equals(pendingId)) {
                        o.put("name", pendingName);
                        saveIndex(arr);
                        return true;
                    }
                }
                JSONObject o = new JSONObject();
                o.put("id", pendingId);
                o.put("name", pendingName);
                o.put("page", 1);
                o.put("pages", 0);
                o.put("size", size);
                arr.put(o);
                saveIndex(arr);
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public long getBookSize(String id) {
            return new File(dir(), id + ".pdf").length();
        }

        @JavascriptInterface
        public String getBookChunk64(String id, long offset, int len) {
            try {
                File f = new File(dir(), id + ".pdf");
                FileInputStream in = new FileInputStream(f);
                in.skip(offset);
                byte[] buf = new byte[len];
                int r = in.read(buf);
                in.close();
                if (r < 0) r = 0;
                if (r != len) {
                    byte[] cut = new byte[r];
                    System.arraycopy(buf, 0, cut, 0, r);
                    buf = cut;
                }
                return Base64.encodeToString(buf, Base64.DEFAULT);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public boolean updateBook(String id, int page, int pages) {
            try {
                JSONArray arr = new JSONArray(listBooks());
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    if (o.getString("id").equals(id)) {
                        o.put("page", page);
                        if (pages > 0) o.put("pages", pages);
                        saveIndex(arr);
                        return true;
                    }
                }
            } catch (Exception e) {}
            return false;
        }

        @JavascriptInterface
        public boolean deleteBook(String id) {
            try {
                new File(dir(), id + ".pdf").delete();
                JSONArray arr = new JSONArray(listBooks());
                JSONArray na = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    if (!arr.getJSONObject(i).getString("id").equals(id)) na.put(arr.getJSONObject(i));
                }
                saveIndex(na);
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void exit() { finish(); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 42 && fileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if (results == null && resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int j = 0; j < n; j++) results[j] = data.getClipData().getItemAt(j).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }

    /* כפתור החזור: קודם סוגר את הקורא/אזור ההורים דרך ה-JS, ורק אז יוצא */
    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("window.__backPressed && window.__backPressed()", null);
        } else {
            super.onBackPressed();
        }
    }
}
